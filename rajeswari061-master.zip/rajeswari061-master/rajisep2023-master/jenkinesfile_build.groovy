pipeline {
    agent any
    parameters {
     string(name: 'PERSON', defaultValue: 'Mr Jenkins', description: 'Who should I say hello to?')
     booleanParam(name: 'TOGGLE', defaultValue: true, description: 'Toggle this value')
     choice(name: 'CHOICE', choices: ['One', 'Two', 'Three'], description: 'Pick something')
     string(name: 'SOURCE_BRANCH', defaultValue: 'developement', description: 'Who should I say hello to?')
    }
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
        timeout(time: 1, unit: 'HOURS') 
    }
    stages {
        stage("clone code") {
            steps {
                checkout([$class: 'GitSCM', branches: [[name: "${env.SOURCE_BRANCH}"]], doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: [[ credentialsId: 'sep2023' , url: 'https://github.com/KuruvaSomaSekhar/rajisep2023.git']]])
                sh "ls -lart ./*"
            }
        }
        stage("build code") {
            steps {
                sh "mvn clean package"
            }
        }
        stage("upload sep23bucket to s3") {
            steps {
                sh "aws s3 cp target/hello-*.war s3://sep23bucket/$JOB_NAME/${params.SOURCE_BRANCH}/$BUILD_NUMBER/"
            }
        } 
        stage("print params") {
            steps {
                sh"""
                echo "Hello ${params.PERSON}"
                echo "Toggle: ${params.TOGGLE}"
                echo "Choice: ${params.CHOICE}"
                 """
            }
        }    
    }
}